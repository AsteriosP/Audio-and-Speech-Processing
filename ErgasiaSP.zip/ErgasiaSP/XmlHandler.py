import xml.etree.ElementTree as ET
import os

class XmlHandler():
    def __init__(self):
        self.tree = ET.parse('/home/steve/Desktop/ErgasiaSP/template.xml')
        self.root = self.tree.getroot()
        self.batch = self.root.find("batch")
        self.fileSet = self.batch.find("fileSet")
        self.features = self.batch.find("settings").findall("feature")


        # append an element to fileSet
        # elem = ET.Element("fileSet",{})
        # elem.text = "test/path"
        # self.fileSet.append(elem)
        

    def setFeaturesToEctract(self, features):
        for feature in self.features:
            ftext = feature.find("name").text
            if ftext in features:
                feature.find("active").text = "true"
            else:
                feature.find("active").text = "false"
    
    def setFiles(self, filePaths):
        for fpath in filePaths:
            elem = ET.Element("fileSet",{})
            elem.text = fpath
            self.fileSet.append(elem)
    
    def saveToFile(self):
        mydata = ET.tostring(self.root)
        print("file Path"os.getcwd())
        myfile = open("batch_file.xml", "wb")  
        myfile.write(mydata)


if __name__ == "__main__":
    t = XmlHandler()
    
    # for child in t.root:
    #     print(child.tag, child.attrib)

