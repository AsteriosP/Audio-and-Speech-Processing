/**
 *
 */
package jAudioFeatureExtractor.Aggregators;

import junit.framework.TestCase;

/**
 * @author mcennis
 *
 */
public class StandardDeviationTest extends TestCase {

	public static void main(String[] args) {
		junit.textui.TestRunner.run(StandardDeviationTest.class);
	}

	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

}
