/**
 *
 */
package jAudioFeatureExtractor;

/**
 * @author mcennis
 *
 */
public class ExplicitCancel extends Exception {

	public ExplicitCancel(String message){
		super(message);
	}
}
